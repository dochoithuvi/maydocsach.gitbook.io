# MayDocSach E-Reader Wizard — GitBook Custom Integration

Custom GitBook integration that renders the public MayDocSach E-Reader Wizard inside a GitBook page.

Wizard URL:

https://dochoithuvi.github.io/maydocsach.gitbook.io/wizard/

## What this integration does

- Adds an **E-Reader Wizard** block to GitBook's insert menu.
- Handles the Wizard URL when it is pasted into GitBook using GitBook's `@link.unfurl` action.
- Renders the Wizard through GitBook's `webframe` component.
- Uses no GitBook permissions/scopes beyond rendering the block.
- Keeps the Wizard application and model data on GitHub Pages.

## Requirements

GitBook's current integration workflow requires Node.js 18+ and the GitBook CLI. This package uses Node 20 via `.nvmrc`.

Install the CLI:

```bash
npm install @gitbook/cli -g
```

Create a GitBook personal developer token in your developer settings, then authenticate:

```bash
gitbook auth
```

## 1. Install dependencies

From this directory:

```bash
npm install
```

Optional local type check:

```bash
npm run build
```

## 2. Publish the integration

The manifest is currently configured with:

```yaml
organization: dochoithuvi
visibility: private
```

Publish:

```bash
gitbook publish
```

GitBook will return an install link. Open that link and install the integration into the MayDocSach space/site.

If GitBook says the organization cannot be found, replace `organization: dochoithuvi` in `gitbook-manifest.yaml` with the exact GitBook organization ID or subdomain shown in your GitBook URL/settings, then publish again.

## 3. Use it in GitBook

After installation, in the GitBook editor:

### Option A — paste the Wizard URL

Paste:

```text
https://dochoithuvi.github.io/maydocsach.gitbook.io/wizard/
```

The integration is configured to handle this URL and render it with a webframe.

### Option B — insert the custom block

Open the `/` insert menu and choose:

**E-Reader Wizard**

The block defaults to the MayDocSach Wizard URL.

### Option C — GitBook Markdown

When using GitBook's generated custom-block Markdown syntax, the intended shape is:

```text
{% embed url="https://dochoithuvi.github.io/maydocsach.gitbook.io/wizard/" %}
```

Use the editor-generated syntax if your GitBook version serializes custom blocks differently.

## 4. Local development

GitBook's workflow is publish → install → dev. `gitbook dev` proxies the installed integration into GitBook; you do not open the dev-server URL directly.

```bash
gitbook dev
```

Then open the connected GitBook editor and refresh the page/block.

## Updating the Wizard later

The integration is intentionally thin. The normal model/database update flow remains on GitHub Pages:

```text
models.json / questions.json
        ↓
GitHub Pages Wizard
        ↓
GitBook webframe
```

Updating `models.json`, `questions.json`, or the Wizard application does not require republishing this GitBook integration as long as the Wizard URL stays the same.

Republish this integration only when changing the GitBook integration code/manifest itself.

## Security notes

- Do not put GitBook personal access tokens in this repository.
- Keep the integration `private` during development.
- Do not add affiliate secrets, Sub_ID registries, API keys, or internal analytics data to this project.
