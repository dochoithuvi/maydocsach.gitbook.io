import { createComponent, createIntegration } from '@gitbook/runtime';

type EmbedProps = {
  url?: string;
};

const DEFAULT_WIZARD_URL =
  'https://dochoithuvi.github.io/maydocsach.gitbook.io/wizard/';

function isAllowedWizardUrl(url: string): boolean {
  try {
    const parsed = new URL(url);
    return (
      parsed.protocol === 'https:' &&
      parsed.hostname === 'dochoithuvi.github.io' &&
      parsed.pathname.startsWith('/maydocsach.gitbook.io/wizard')
    );
  } catch {
    return false;
  }
}

const embedBlock = createComponent<EmbedProps>({
  componentId: 'embed',

  async action(element, action) {
    switch (action.action) {
      case '@link.unfurl': {
        const url = action.url;

        if (typeof url !== 'string' || !isAllowedWizardUrl(url)) {
          return element;
        }

        return {
          props: {
            url,
          },
        };
      }

      default:
        return element;
    }
  },

  async render(element, context) {
    const url =
      typeof element.props.url === 'string' && isAllowedWizardUrl(element.props.url)
        ? element.props.url
        : DEFAULT_WIZARD_URL;

    const theme =
      context?.theme === 'dark'
        ? 'dark'
        : context?.theme === 'light'
          ? 'light'
          : undefined;

    const params = new URLSearchParams();
    if (theme) params.set('theme', theme);
    params.set('embed', 'gitbook');

    const themedUrl = `${url}${url.includes('?') ? '&' : '?'}${params.toString()}`;

    return (
      <block>
        <webframe
          source={{ url: themedUrl }}
          // Safe initial fallback on narrow screens. The frame can then resize
          // itself using the GitBook @webframe.resize postMessage action.
          aspectRatio={0.5}
        />
      </block>
    );
  },
});

export default createIntegration({
  components: [embedBlock],
});
